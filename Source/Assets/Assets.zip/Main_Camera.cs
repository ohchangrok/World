﻿using UnityEngine;
using System.Collections;

public class Main_Camera : MonoBehaviour
{
    public GameObject m_objTarget = null;
    void LateUpdate()
    {
        Vector3 vec = m_objTarget.transform.position - transform.position;
        transform.position += vec / 8f;
    }
}
