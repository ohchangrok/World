﻿using UnityEngine;
using System.Collections;

public class Object_House : Object_Parent
{
   
}
