﻿using UnityEngine;
using System.Collections;

public class Touch_Panel : MonoBehaviour {

    public Object_Parent m_pObject = null;
	void Start ()
    {
	
	}

    void OnPress(bool _isPress)
    {
        if (!_isPress)
        {
            UICamera.MouseOrTouch pCurTouch = UICamera.currentTouch;
            if (_isPress) return;
            Vector3 pos = UICamera.currentTouch.pos;


            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            int layer = (1 << (LayerMask.NameToLayer("Object")) | 1 << (LayerMask.NameToLayer("Ground")));
            if (Physics.Raycast(ray, out hit, layer))
            {
                if (hit.transform.gameObject.layer == LayerMask.NameToLayer("Ground"))
                    m_pObject.SetTarget(hit.point);
                else if (hit.transform.gameObject.layer == LayerMask.NameToLayer("Object"))
                {
                    Object_Parent pParant = hit.transform.gameObject.GetComponent<Object_Parent>();
                    if (pParant != null)
                        pParant.MakeTarget(m_pObject.gameObject);

                   
                }
            }
        }


    }
}
