﻿using UnityEngine;
using System.Collections;

public static class Core_Town
{
    public static Object_Parent m_pObject_House = null;
    public static Object_Parent m_pObject_TownHouse = null;
}
