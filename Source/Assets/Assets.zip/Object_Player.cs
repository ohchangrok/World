﻿using UnityEngine;
using System.Collections;

public class Object_Player : Object_Parent
{
    GameObject m_objTarget = null;
    NavMeshAgent m_pNav = null;
    void Start()
    {
        m_pNav = GetComponent<NavMeshAgent>();

    }
    public override void SetTarget(GameObject _target)
    {
        m_pNav.SetDestination(_target.transform.position);
    }
    public override void SetTarget(Vector3 _pos)
    {
        
        m_pNav.Resume();
        m_pNav.SetDestination(_pos);
        Debug.Log(_pos);
    }
    //void Update()
    //{
    //    if (m_objTarget != null)
    //    {


    //    }

    //}
}
