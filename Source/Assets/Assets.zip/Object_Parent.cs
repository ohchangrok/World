﻿using UnityEngine;
using System.Collections;

public class Object_Parent : MonoBehaviour
{
    public virtual void SetTarget(GameObject _target)
    {

    }
    public virtual void SetTarget(Vector3 _pos)
    {

    }
    public virtual void MakeTarget(GameObject _obj)
    {


    }
}
