﻿using UnityEngine;
using System.Collections;

public class Object_TownHouse : Object_Parent
{

    GameObject m_objPoint = null;
    GameObject m_obj = null;
    void Start()
    {
        m_objPoint = transform.FindChild("Point").gameObject;

    }

    public override void SetTarget(GameObject _target)
    {

    }
    public override void SetTarget(Vector3 _pos)
    {

    }
    public override void MakeTarget(GameObject _obj)
    {
        m_obj = _obj;
        _obj.GetComponent<Object_Parent>().SetTarget(m_objPoint);
        StartCoroutine(this.MakeTargetDis());
    }
    IEnumerator MakeTargetDis()
    {
        while (true)
        {
            float dis = Vector3.Distance(m_objPoint.transform.position, m_obj.transform.position);
            Debug.Log(dis);
            if (dis < 1f)
            {
                Debug.Log("Fnish");
                m_obj = null;
                break;
            }
            yield return new WaitForSeconds(0.025f);
        }
    }
}
