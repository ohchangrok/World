﻿using UnityEngine;
using System.Collections;

public class Scene_Town : MonoBehaviour {

    GameObject m_objTown = null;
    GameObject m_objHouse = null;

	void Start ()
    {
        m_objTown = Instantiate(Resources.Load("Ground/Obj_Town")) as GameObject;

	}
	
	
	void Update ()
    {
	
	}
}
